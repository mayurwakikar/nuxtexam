
import { defuFn } from 'defu'

const inlineConfig = {}



export default defuFn(inlineConfig)
